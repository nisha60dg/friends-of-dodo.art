<?php
add_action( 'wp_enqueue_scripts', 'enqueue_child_theme_setup' );
function enqueue_child_theme_setup(){
	$parenthandle = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.
    $theme = wp_get_theme();
    wp_enqueue_style( $parenthandle, get_template_directory_uri() . '/style.css', array(),  $theme->parent()->get('Version'));
    wp_enqueue_style( 'child-style', get_stylesheet_uri(),array( $parenthandle ),$theme->get('Version'));
}

/*
 ***************
 Shows Custom Post Type Starts Here
 ***************
*/

add_action('init', function(){
    
	// Openings
	$labels = array(
        "name" => "Openings",
        "singular_name" => "Opening",
		"all_items" => "All Openings",
        "add_new" => "Add New Opening",
        "add_new_item" => "Add New Opening",
        "edit" => "Edit",
        "edit_item" => "Edit Opening",
        "new_item" => "New Opening",
        "view" => "View",
        "view_item" => "View Opening",
        "search_items" => "Search Openings",
        "not_found" => "No Opening Found",
        "not_found_in_trash" => "No Openings Found in Trash",
        "parent" => "Parent Opening",
    );

    $args = array(
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "show_ui" => true,
        "has_archive" => true,
        "show_in_menu" => true,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
		'menu_icon' => 'dashicons-image-filter',
        "hierarchical" => false,
        "rewrite" => array( "slug" => "openings", "with_front" => true ),
        "query_var" => true,
        "supports" => array( "title", "editor", "revisions", "thumbnail" )
    );

    register_post_type( "openings", $args );
	
	// Shows
	$labels = array(
		'name' => _x( 'Shows', 'taxonomy general name' ),
		'singular_name' => _x( 'Show', 'taxonomy singular name' ),
		'search_items' =>  __( 'Search Shows' ),
		'all_items' => __( 'All Shows' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Shows' ), 
		'update_item' => __( 'Update Shows' ),
		'add_new_item' => __( 'Add New Show' ),
		'new_item_name' => __( 'New Show Name' ),
		'menu_name' => __( 'Shows' ),
	  );    
	 
	  register_taxonomy('shows',array('openings'), array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'show_in_rest' => true,
		'show_admin_column' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'shows' ),
	  ));
	  
	  
	// Artists
    $labels = array(
        "name" => "Artists",
        "singular_name" => "Artist",
		"add_new_item" => "Add New Artist",
		"add_new" => "Add New Artist",
    );

    $args = array(
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "show_ui" => true,
        "has_archive" => true,
        "show_in_menu" => true,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
		'menu_icon' => 'dashicons-businessman',
        "hierarchical" => true,
        "rewrite" => array( "slug" => "artists", "with_front" => true ),
        "query_var" => true,
        "supports" => array( "title", "editor", "revisions", "thumbnail","custom" )
    );

    register_post_type( "artists", $args );

});

// Artworks
	$labels = array(
        "name" => "Artworks",
        "singular_name" => "Artwork",
		"all_items" => "All Artworks",
        "add_new" => "Add New Artwork",
        "add_new_item" => "Add New Artwork",
        "edit" => "Edit",
        "edit_item" => "Edit Artwork",
        "new_item" => "New Artwork",
        "view" => "View",
        "view_item" => "View Artwork",
        "search_items" => "Search Artworks",
        "not_found" => "No Artwork Found",
        "not_found_in_trash" => "No Artwork Found in Trash",
        "parent" => "Parent Artwork",
    );

    $args = array(
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "show_ui" => true,
        "has_archive" => true,
        "show_in_menu" => true,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
		'menu_icon' => 'dashicons-layout',
        "hierarchical" => false,
        "rewrite" => array( "slug" => "ortworks", "with_front" => true ),
        "query_var" => true,
        "supports" => array( "title", "editor", "revisions", "thumbnail" )
    );

    register_post_type( "artworks", $args );
	

	

// Include custom files
require_once get_stylesheet_directory().'/inc/art-functions.php';
require_once get_stylesheet_directory().'/inc/show-functions.php';
?>