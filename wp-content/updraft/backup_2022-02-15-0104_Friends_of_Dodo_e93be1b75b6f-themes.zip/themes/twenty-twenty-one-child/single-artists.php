<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();

global $post;

/* Start the Loop */
while ( have_posts() ) :
	the_post();

	get_template_part( 'template-parts/content/content-single' );
	$_artist_twitter_username = get_post_meta( $post->ID, '_artist_twitter_username', true );
    $_artist_instagram_username = get_post_meta( $post->ID, '_artist_instagram_username', true );
	
	$args = [
		'meta_query' => [
			[
				'key'   =>  '_event_artists',
				'value'   => '(^|,)'.$post->ID.'(,|$)',
				'compare'  =>  'REGEXP'
				]
			]
	];
	$artistOpenings = artgallery_get_posts('openings', $args);
	$showsArray = $artistShows = [];
	if(!empty($artistOpenings)){
		foreach($artistOpenings as $showOpening){
			$openingShows = get_the_terms($showOpening->ID, 'shows');
			foreach($openingShows as $showObject){
				if(!in_array($showObject->term_id, $showsArray)){
					$artistShows[] = $showObject;
					$showsArray[] = $showObject->term_id;
				}
			}
		}
	}

	$onGoingShows = [];
	if(!empty($artistShows)){
		foreach($artistShows as $show){
			if($isOnGoing = artgallery_get_shows_openings($show, 'ongoing') ){
				$onGoingShows[] = $isOnGoing;
			}
		}
	}

	if(!empty($onGoingShows)){ ?>
		<div class="artist-show-container">
			<h2>Shows</h2>
			<div class="artist-shows-list">
				<?php foreach($onGoingShows as $show){ ?> 
					<div class="artist-shows-item">
						<div class="show-title">		  
							<a href="<?=get_term_link($show->term_id);?>"><?=$show->name?></a> 
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	<?php }
	
	if(isset($openings) && !empty($openings)){
		$artist_gallery = artgallery_get_artist_gallery($post->ID, $openings->ID);
		if(!empty($artist_gallery)){
			$gallery_images = explode(",", $artist_gallery->gallery_images);			
		?>
			<div class="artist-artwork-wrapper">	
			<!---<h2>Artworks</h2>--->
			<div class="artist-artwork-gallery">				
				<?php foreach($gallery_images as $index=>$attachment){ ?>				
					<?php 
						$gallery_image_src = wp_get_attachment_url($attachment);
						$image_data = get_post($attachment);
						//pr($image_data);
					?>
					<a href="<?=$gallery_image_src?>" class="gallery-item"  title="<?=$image_data->post_title ?>" data="<?=$image_data->post_content ?>"  categories="<?=$image_data->post_excerpt ?>" >
						<img src="<?=$gallery_image_src?>" class="artist-artwork-img" alt="<?=$image_data->post_excerpt ?>" />
					</a>
				<?php } ?>
			</div>
				</div>
		<?php }
	}
endwhile; // End of the loop.

?>

<link rel="stylesheet" href="/wp-content/themes/twenty-twenty-one-child/inc/assets/css/magnific-popup.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="/wp-content/themes/twenty-twenty-one-child/inc/assets/js/jquery.magnific-popup.min.js"></script>
<script>
		$(document).ready(function() {
			var twitter = '<?=$_artist_twitter_username ?>';
			var instagram = '<?=$_artist_instagram_username  ?>';
				console.log(twitter);
			$('.artist-artwork-gallery').magnificPopup({
				delegate: 'a',
				type: 'image',
				tLoading: 'Loading image #%curr%...',
				mainClass: 'mfp-img-mobile',
				gallery: {
					enabled: true,
					navigateByImgClick: true,
					preload: [0,1] // Will preload 0 - before current, and 1 after the current image
				},
				image: {
					tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
					titleSrc: function(item) {
						return '<p><strong>' + item.el.attr('title') + '</strong></br>' + item.el.attr('data') + '</p><br><br><p><strong>Categories:</strong><br>' + item.el.attr('categories') + '</p><br><br><p><strong>Twitter:</strong><br>@friends.of.dodo<br>@twelveartists<br>'+ twitter +'</p><br><br>' + '<p><strong>Instagram:</strong><br>@friends.of.dodo<br>@twelveartists<br>'+ instagram +'</p>';
					}
				}
			});
		});
	</script>
	
<?php
get_footer();
