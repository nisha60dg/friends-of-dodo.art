<?php
/**
 * 
 * 
 * 
 */
?>
<option value="">Select Event Date</option>
<?php foreach($openings as $event){ 
    $event_date = get_post_meta( $event->ID, '_event_date', true );
    ?>
    <option value="<?=$event->ID?>"><?=$event_date?></option>
<?php } ?>
