jQuery(function($){
    
    if($('.select2').length){
        $('.select2').select2({
            
        });
    }
});